new Oidc.UserManager().signinSilentCallback();
